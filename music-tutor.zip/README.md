# Music Tutor
A CLI-based app to help with guitar note recognition and music training.
