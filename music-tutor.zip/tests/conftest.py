import sys
import os

# Correct path joining — everything must be in quotes
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))