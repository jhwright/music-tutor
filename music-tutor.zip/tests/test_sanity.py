def test_basic_math():
    assert 2 + 2 == 4

def test_string_handling():
    assert "music".upper() == "MUSIC"