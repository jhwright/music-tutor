# tests/test_cli.py
import pytest
from cli import parse_args, main

def test_parse_note_flag():
    args = parse_args(["--note", "A3"])
    assert args.note == "A3"
    assert not args.play

def test_parse_play_flag():
    args = parse_args(["--play"])
    assert args.play is True
    assert args.note is None

def test_parse_version_flag(capsys):
    with pytest.raises(SystemExit):
        parse_args(["--version"])
    captured = capsys.readouterr()
    assert "music-tutor 0.1" in captured.out