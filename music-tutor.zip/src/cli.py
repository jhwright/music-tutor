# src/cli.py
import argparse

def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="Music Tutor CLI: Train your musical ear and recognize guitar notes."
    )
    parser.add_argument(
        "--note", type=str, help="Play and identify this note (e.g. E2, A3, C#4)"
    )
    parser.add_argument(
        "--play", action="store_true", help="Play a random note for identification"
    )
    parser.add_argument(
        "--version", action="version", version="music-tutor 0.1"
    )
    return parser.parse_args(argv)

def main(argv=None):
    args = parse_args(argv)

    if args.note:
        print(f"[stub] Play the note: {args.note}")

    elif args.play:
        print("[stub] Playing a random note for recognition...")

    else:
        print("Run with --help to see available options.")